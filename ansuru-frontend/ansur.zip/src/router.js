import Vue from 'vue'

import VueRouter from 'vue-router'
Vue.use(VueRouter)

export function ansurRouter () {
  return new VueRouter({
    mode: 'history',
    routes: [
      { path: '/', 
      component: () => import('./components/Index.vue') },
      { path: '/user-login', 
      component: () => import('./components/UserLogin.vue') },
      { path: '/user-signup', 
      component: () => import('./components/UserSignup.vue') },
      { path: '/user-guide', 
      component: () => import('./components/UserGuide.vue') },
      { path: '/user-forgot-pswd', 
      component: () => import('./components/UserForgotPswd.vue') },
      { path: '/user-change-pswd', 
      component: () => import('./components/UserChangePswd.vue') },
      { path: '/user-list',
       component: () => import('./components/UserList.vue') },
      { path: '/user-home',
      component: () => import('./components/UserHome.vue') },
      { path: '/user-edit',
      component: () => import('./components/UserEdit.vue') },
      
      { path: '/item-register', 
      component: () => import('./components/ItemRegister.vue') },
      // { path: '/item/:id', component: () => import('./components/Item.vue') }
    ]
  })
}