<template>
  <div id="Signup">
		<el-col :span="8" :offset="8">
			<el-card>
				<h2 id="login-title"> ログイン</h2>
				<el-form ref="loginForm" :model="loginForm">

					<el-row>
						<el-form-item label="名前" id="gap-adjust"></el-form-item>
						<el-input v-model="loginForm.name"></el-input>
					</el-row>
					<el-row>
						<el-form-item label="パスワード" id="gap-adjust"></el-form-item>
						<el-input v-model="loginForm.password"></el-input>
					</el-row>
					
					<el-row id="text-center">
						<div id="gap-adjust">
							<el-button type="primary" size="small" v-on:click="userLogin">ログイン</el-button>
						</div>
					</el-row>

					<el-row id="gap-adjust">
						<a href="#" @click.prevent="forgetPassword">パスワード忘れた方はこちら</a>
					</el-row>

				</el-form>
			</el-card>
		</el-col>

	</div>
</template>

<script>
export default {
  name: 'Signup',
	data:function() {
		return {
			loginForm: {
				name: '',
				password: '',
			},
		}	
	},
	methods: {
		forgetPassword() {
			this.$router.push({path: '/user-forgot-pswd'})
		},
		userLogin() {
			// if the name and password is correct
			// userType == admin 
			// this.$router.push({path: '/user-list'})
			// userType == user 
			this.$router.push({path: '/user-home'})

		}
	},
}
</script>


<style scoped>
	#gap-adjust {
		margin-bottom: 0px;
		margin-top: 20px;
	}
	#text-center {
		text-align: center;
	}
	#login-title {
		text-align: center;
		color: #2082e5;
	}
	a {
		text-decoration: none;
	}
	.el-form-data {
		color: #000!important;
	}
</style>